namespace MSSAWordle
{

    /**Needs
     * A file that stores 100-1000 5 letter words
     * Ability to get a new word (random) to play the game
     * Ability to get the user input for the current row
     * Ability to compare to current word
     * Ability to disply winning message or failing message
    */
    
    public partial class Form1 : Form
    {
        private int CurrentOffset = 1;
        private string CurrentWord = string.Empty;

        public Form1()
        {
            InitializeComponent();
            StartNewGame();
        }

        private void StartNewGame()
        {
            //get a new word from word list [open file, get all words, choose one at random]
            CurrentWord = "MUDDY";

            //reset offset
            CurrentOffset = 1;
            //enable submit
            btnSubmit.Enabled = true;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //1) Get the next user-entered word:

            
            //2) Check it: If correct cool, we're done [disable submit]
            
            //3) If not, color boxes
                //yellow if good char but in wrong place
                //green if good char and in correct place


            //increment the offset (row)
            CurrentOffset++;
            if (CurrentOffset > 6)
            {
                MessageBox.Show("Sorry you didn't win this time!" +
                    "The correct word was: " + CurrentWord);
                btnSubmit.Enabled = false;
            }
        }

        private string GetInput()
        {
            //1) What line are we on?
            //use the offset to get the next row
            //when offset is 1, boxes 1-5
            //when offset is 2, boxes 6-10
            //... 3, 4, 5 ...
            //when offset is 6, boxes 26-30

            //2) Are all the chars present?

            //3) Is it a valid word?

            //if one of the first three fails, decrement current row counter
            //display message (invalid/incomplete word)


            //using the row, populate the userWord;
            string userWord = "WATER"; //update from form

            //return the word from the User:
            return userWord;
        }

        private bool IsCorrectWord(int offset)
        {
            //get the word they entered

            //return currentWord == wordTheyEntered
            return false;
        }

        private void btnNewWord_Click(object sender, EventArgs e)
        {
            StartNewGame();
            
        }

        private void btnTestValues_Click(object sender, EventArgs e)
        {
            textBox1.Text = "A";
            textBox2.Text = "B";
            textBox3.Text = "C";
            textBox4.Text = "D";
            textBox5.Text = "E";
            textBox6.Text = "F";
            textBox7.Text = "G";
            textBox8.Text = "H";
            textBox9.Text = "I";
            textBox10.Text = "J";
            textBox11.Text = "K";
            textBox12.Text = "L";
            textBox13.Text = "M";
            textBox14.Text = "N";
            textBox15.Text = "O";
            textBox16.Text = "P";
            textBox17.Text = "Q";
            textBox18.Text = "R";
            textBox19.Text = "S";
            textBox20.Text = "T";
            textBox21.Text = "U";
            textBox22.Text = "V";
            textBox23.Text = "W";
            textBox24.Text = "X";
            textBox25.Text = "Y";
            textBox26.Text = "Z";
            textBox27.Text = "0";
            textBox28.Text = "1";
            textBox29.Text = "2";
            textBox30.Text = "3";
        }
    }
}